<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Adien - catatan perjalan</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="<?= base_url('assets') ?>/css/styles.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
</head>

<body class="sb-nav-fixed">
    <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
        <!-- Navbar Brand-->
        <a class="navbar-brand ps-3" href="<?= base_url('c_Dashboard') ?>"> Pengaduan masyarakat</a>
        <!-- Sidebar Toggle-->
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
        <!-- Navbar-->
        <ul class="navbar-nav ms-auto ms-auto me-0 me-md-3 my-2 my-md-0">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-user fa-fw"></i></a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li><a class="dropdown-item" href="<?= base_url() ?>c_NewLogin/logout">Logout</a></li>
                </ul>
            </li>
        </ul>drop
    </nav>
    <div id="layoutSidenav">
        <div id="layoutSidenav_nav">
            <nav class="sb-sidenav accordion sb-sidenav-light" id="sidenavAccordion">
                <div class="sb-sidenav-menu">
                    <div class="nav">
                        <div class="sb-sidenav-menu-heading">Core</div>
                        <a class="nav-link" href="<?= base_url('c_Dashboard') ?>">
                            <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                            Dashboard
                        </a>

                        <div class="sb-sidenav-menu-heading">Master Data</div>
                        <a class="nav-link collapsed" href="<?= base_url('c_admin/kategori') ?>" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fa fa-database"></i></div>
                            Kategori
                        </a>
                        <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                        </div>
                        <a class="nav-link collapsed" href="<?= base_url('c_admin/masyarakat') ?>" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fa fa-database"></i></div>
                            Masyarakat
                        </a>
                        <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                        </div>
                        <a class="nav-link collapsed" href="<?= base_url('c_Dashboard/lihatperjalanan') ?>" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fa fa-database"></i></div>
                            Petugas
                        </a>

                        <div class="sb-sidenav-menu-heading">pengaduan</div>
                        <a class="nav-link collapsed" href="<?= base_url('c_Dashboard/tuliscatatan') ?>" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fa fa-pencil"></i></div>
                            Tulis laporan
                        </a>
                        <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                        </div>
                        <a class="nav-link collapsed" href="<?= base_url('c_Dashboard/lihatperjalanan') ?>" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                            <div class="sb-nav-link-icon"><i class="fa fa-database"></i></div>
                            lihat laporan
                        </a>

                    </div>
                </div>
                <div class="sb-sidenav-footer">
                    <div class="small">Logged in as:</div>
                    Start Bootstrap
                </div>
            </nav>
        </div>
        <div id="layoutSidenav_content">
            <main>
                 <div class="card-body">
              <div class="table-responsive">
                <table id="basic-datatables" class="display table table-striped table-hover" >
                  <thead>
                    <tr>
                      <th width="8%">No</th>
                      <th>Kategori</th>
                      <th width="15%"></th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>No</th>
                      <th>Kategori</th>
                      <th></th>
                    </tr>
                  </tfoot>
                  <tbody>
                                          <tr>
                        <td>1</td>
                        <td>Prasarana Umum</td>
                        <td>
                                                      <a href="#" class="btn btn-xs btn-warning"><i class="far fa-edit"></i></a>
                            <a href="#" class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></a>
                                                  </td>
                      </tr>
                                          <tr>
                        <td>2</td>
                        <td>Lingkungan Hidup</td>
                        <td>
                                                      <a href="#" class="btn btn-xs btn-warning"><i class="far fa-edit"></i></a>
                            <a href="#" class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></a>
                                                  </td>
                      </tr>
                                          <tr>
                        <td>3</td>
                        <td>Perhubungan</td>
                        <td>
                                                      <a href="#" class="btn btn-xs btn-warning"><i class="far fa-edit"></i></a>
                            <a href="#" class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></a>
                                                  </td>
                      </tr>
                                          <tr>
                        <td>4</td>
                        <td>Kesehatan</td>
                        <td>
                                                      <a href="#" class="btn btn-xs btn-warning"><i class="far fa-edit"></i></a>
                            <a href="#" class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></a>
                                                  </td>
                      </tr>
                                          <tr>
                        <td>5</td>
                        <td>Pelanggaran Peraturan Daerah</td>
                        <td>
                                                      <a href="#" class="btn btn-xs btn-warning"><i class="far fa-edit"></i></a>
                            <a href="#" class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></a>
                                                  </td>
                      </tr>
                                          <tr>
                        <td>6</td>
                        <td>Perizinan</td>
                        <td>
                                                      <a href="#" class="btn btn-xs btn-warning"><i class="far fa-edit"></i></a>
                            <a href="#" class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></a>
                                                  </td>
                      </tr>
                                          <tr>
                        <td>7</td>
                        <td>Sosial</td>
                        <td>
                                                      <a href="#" class="btn btn-xs btn-warning"><i class="far fa-edit"></i></a>
                            <a href="#" class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></a>
                                                  </td>
                      </tr>
                                          <tr>
                        <td>8</td>
                        <td>Perpajakan</td>
                        <td>
                                                      <a href="#" class="btn btn-xs btn-warning"><i class="far fa-edit"></i></a>
                            <a href="#" class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></a>
                                                  </td>
                      </tr>
                                          <tr>
                        <td>9</td>
                        <td>Komunikasi dan Informatika</td>
                        <td>
                                                      <a href="#" class="btn btn-xs btn-warning"><i class="far fa-edit"></i></a>
                            <a href="#" class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></a>
                                                  </td>
                      </tr>
                                          <tr>
                        <td>10</td>
                        <td>Kepegawaian</td>
                        <td>
                                                      <a href="#" class="btn btn-xs btn-warning"><i class="far fa-edit"></i></a>
                            <a href="#" class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></a>
                                                  </td>
                      </tr>
                                          <tr>
                        <td>11</td>
                        <td>Pelayanan Kecamatan Kelurahan</td>
                        <td>
                                                      <a href="#" class="btn btn-xs btn-warning"><i class="far fa-edit"></i></a>
                            <a href="#" class="btn btn-xs btn-danger"><i class="fas fa-trash"></i></a>
                                                  </td>
                      </tr>
                                      </tbody>
                </table>
              </div>
            </div>
            </main>
            <footer class="py-4 bg-light mt-auto">
                <div class="container-fluid px-4">  
                    <div class="d-flex align-items-center justify-content-between small">
                        <div class="text-muted">Copyright &copy; Adien_Ubx 2022</div>
                        <div>
                            <a href="#">Privacy Policy</a>
                            &middot;
                            <a href="#">Terms &amp; Conditions</a>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    <script src="<?= base_url('assets') ?>/js/scripts.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <script src="<?= base_url('assets') ?>/assets/demo/chart-area-demo.js"></script>
    <script src="<?= base_url('assets') ?>/assets/demo/chart-bar-demo.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
    <script src="<?= base_url('assets') ?>/js/datatables-simple-demo.js"></script>
</body>

</html>
<?php
defined('BASEPATH') or exit('No direct script access allowed');

class c_admin extends CI_Controller
{

	public function index(){
		$data['user']=$this->db->get_where('petugas',['username'=>$this->session->userdata('username')])->row_array();
		$this->load->view('admin/v_dashboard',$data);
	}
	public function kategori()
	{
		$data['title'] = 'Kategori';
		$this->load->view('admin/v_kategori', $data);
	}

	public function masyarakat(Type $var = null)
	{
		$data['title'] = 'Kategori';
		$this->load->view('admin/v_masyarakat', $data);
	}

	// Admin
	public function edit_admin($id)
	{
		$name = $this->input->post('name');
		$role_id = $this->input->post('role_id');

		$update = array(
			'full_name' => $name,
			'role_id' => $role_id,
		);
		$this->db->where('id', $id);
		$this->db->update('user', $update);


		redirect('C_admin');
	}


	public function delete_admin($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('user');
		redirect('C_admin');
	}


}

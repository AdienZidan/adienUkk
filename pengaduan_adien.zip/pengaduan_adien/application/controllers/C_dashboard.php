<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class c_Dashboard extends CI_Controller {

	public function index()
	{

		$this->load->model('mdl_newlogin');

		// manggil nama user yang login menggunakan model
		// $data['user'] = $this->mdl_newlogin->get_user_data($this->session->userdata('username'))->row_array();

		// manggil nama user yang login menggunakan controler
		$data['user']=$this->db->get_where('masyarakat',['username'=>$this->session->userdata('username')])->row_array(); 

		$data['title'] = 'Dashboard';
		$this->load->view('admin/v_dashboard', $data);
	}

	public function pengaduan()
	{
		$data['user']=$this->db->get_where('masyarakat',['username'=>$this->session->userdata('username')])->row_array();  

		$data['title'] = 'Dashboard';
		$this->load->view('admin/v_pengaduan', $data);
	}
	public function tambahcatatan()
	{
		$data['user']=$this->db->get_where('user',['email'=>$this->session->userdata('email')])->row_array(); 

		$tanggal=$this->input->post('tanggal');
		$waktu=$this->input->post('waktu');
		$lokasi=$this->input->post('lokasi');
		$suhu=$this->input->post('suhu');
		$catatan=$this->input->post('catatan');
		$user_data=$this->db->get_where('user',['email'=>$this->session->userdata('email')])->row_array(); 
		$add=array(
			'tanggal' => $tanggal,
			'waktu' => $waktu,
			'lokasi' => $lokasi,
			'suhu' => $suhu,
			'catatan' => $catatan,
			'user_id'=>$user_data['id'],
		);

		$this->load->model('mdl_newLogin');
		$this->mdl_newLogin->tambah_catatan($add);
		$data['title'] = 'Dashboard';
		redirect('c_Dashboard/index');
	}




}